

import os
from azure.core.credentials import AzureKeyCredential
from azure.ai.documentintelligence import DocumentIntelligenceClient
from azure.core.exceptions import HttpResponseError
from dotenv import load_dotenv, find_dotenv

def analyze_local_file(file_path, output_path="output1.txt"):
    load_dotenv(find_dotenv())  # Load .env variables

   
    client = DocumentIntelligenceClient(endpoint, AzureKeyCredential(key))
    
    try:
        with open(file_path, "rb") as f:
            doc_bytes = f.read()
            poller = client.begin_analyze_document("prebuilt-read", body=doc_bytes)
            result = poller.result()

        with open(output_path, "w", encoding="utf-8") as out_file:
            out_file.write(f"Document Content:\n{result.content}\n\n")
            for page in result.pages:
                out_file.write(f"-- Page {page.page_number} ({page.width}x{page.height} {page.unit})\n")
                for line in page.lines:
                    out_file.write(f"Line: {line.content}\n")

        print(f"✅ Analysis saved to '{output_path}'")
    except HttpResponseError as e:
        print("❌ Error:", e)

if __name__ == "__main__":
    analyze_local_file("./SampleDoc.pdf")  # <– Replace with your actual file path